import plotly.express as px
import plotly.graph_objects as go

def create_progress_chart(current, goal):
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=current,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': "Weekly Progress"},
        gauge={
            'axis': {'range': [None, goal]},
            'bar': {'color': "#2E7D32"},
            'steps': [
                {'range': [0, goal/2], 'color': "#E8F5E9"},
                {'range': [goal/2, goal], 'color': "#A5D6A7"}
            ]
        }
    ))
    
    fig.update_layout(height=250)
    return fig

def create_waste_composition_chart(data):
    if data.empty:
        return None
    
    category_totals = data.groupby('category')['weight'].sum().reset_index()
    fig = px.pie(
        category_totals,
        values='weight',
        names='category',
        color_discrete_sequence=['#2E7D32', '#4CAF50', '#81C784', '#A5D6A7']
    )
    fig.update_layout(height=300)
    return fig

def create_trend_chart(data):
    if data.empty:
        return None
    
    daily_totals = data.groupby('date')['weight'].sum().reset_index()
    fig = px.line(
        daily_totals,
        x='date',
        y='weight',
        title='Daily Waste Trend'
    )
    fig.update_traces(line_color='#2E7D32')
    fig.update_layout(height=300)
    return fig

ECO_TIPS = [
    "Bring reusable bags when shopping",
    "Use a reusable water bottle",
    "Compost food scraps",
    "Avoid single-use plastics",
    "Buy products with minimal packaging",
    "Repair items instead of replacing them",
    "Donate or recycle electronics",
    "Use cloth napkins instead of paper"
]

WASTE_CATEGORIES = [
    "Paper",
    "Plastic",
    "Glass",
    "Metal",
    "Organic",
    "Electronics",
    "Other"
]
